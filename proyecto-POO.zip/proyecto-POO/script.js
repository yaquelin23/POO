function crearCuenta() {
    var nuevoUsuario = document.getElementById("nuevo-usuario").value;
    var nuevaContraseña = document.getElementById("nueva-contraseña").value;
    var confirmarContraseña = document.getElementById("confirmar-contraseña").value;

    if (nuevaContraseña !== confirmarContraseña) {
        alert("Las contraseñas no coinciden. Por favor, inténtalo de nuevo.");
        return false; 
    }

    alert("¡Cuenta creada exitosamente!");
    return true; 
}

function validarCredenciales(usuario, contraseña) {
    const usuarioCorrecto = "usuario";
    const contraseñaCorrecta = "contraseña";

    if (usuario === usuarioCorrecto && contraseña === contraseñaCorrecta) {
        return "Inicio de Sesión Exitoso";
    } else if (usuario !== usuarioCorrecto && contraseña === contraseñaCorrecta) {
        return "Usuario Incorrecto";
    } else if (usuario === usuarioCorrecto && contraseña !== contraseñaCorrecta) {
        return "Contraseña Incorrecta";
    } else {
        return "Ambas Credenciales Incorrectas";
    }
}

function iniciarSesion() {
    const usuario = document.getElementById("usuario").value;
    const contraseña = document.getElementById("contraseña").value;

    const resultado = validarCredenciales(usuario, contraseña);

    switch (resultado) {
        case "Inicio de Sesión Exitoso":
            alert("Inicio de sesión exitoso. Redirigiendo a tu perfil.");
            break;
        case "Usuario Incorrecto":
            alert("Usuario incorrecto. Por favor, inténtalo de nuevo.");
            break;
        case "Contraseña Incorrecta":
            alert("Contraseña incorrecta. Por favor, inténtalo de nuevo.");
            break;
        case "Ambas Credenciales Incorrectas":
            alert("Usuario y contraseña incorrectos. Por favor, inténtalo de nuevo.");
            break;
        default:
            alert("Error desconocido. Por favor, inténtalo de nuevo.");
    }
}








class Usuario { username; password; 
    getUsuario() { 
        return this.username; 
    } getContraseña() { return this.password; 
    } 
} 
class Notificacion { mostrarNotificacion(mensaje) { 
    alert(mensaje); 
} 
}
class Sistema { 
    iniciarSesion(usuario, contraseña) { 
        if (usuario === "admin" && contraseña === "123") { 
            const notificacion = new Notificacion(); 
            notificacion.mostrarNotificacion("Acceso permitido"); 
        } else { const notificacion = new Notificacion(); 
            notificacion.mostrarNotificacion("Acceso denegado"); 
        } 
    } 
}
const sistema = new Sistema();  
const usuario = "admin"; const contraseña = "123"; 
sistema.iniciarSesion(usuario, contraseña); 
const verificarUsuario = (user) => { if (user === "admin") { return true; } return false; 
} 
const verificarContraseña = (pass) => { if (pass === "123") { return true; } return false; 
} 
if (!verificarUsuario(usuario)) { const notificacion = new Notificacion(); 
    notificacion.mostrarNotificacion("Usuario incorrecto"); 
} else if (!verificarContraseña(contraseña)) { const notificacion = new Notificacion(); 
    notificacion.mostrarNotificacion("Contraseña incorrecta"); 
} 
const redireccionarPerfil = () => { 
} 
    const completarInformacionPersonal = () => { 
    } 
    const enviarInformacionPerfil = () => { 
}